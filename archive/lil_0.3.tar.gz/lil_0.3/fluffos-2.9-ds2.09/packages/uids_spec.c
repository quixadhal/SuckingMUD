#include "spec.h"

int export_uid(object);
string geteuid(function | object default:F__THIS_OBJECT);
string getuid(object default:F__THIS_OBJECT);
int seteuid(string | int);
