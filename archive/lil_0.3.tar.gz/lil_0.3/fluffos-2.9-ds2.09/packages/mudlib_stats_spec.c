#include "spec.h"

    mapping domain_stats(void | string);
    void set_author(string);
    mapping author_stats(void | string);
