#ifndef FLUFF_EVAL_H
#define FLUFF_EVAL_H
extern int outoftime;
void set_eval(int time);
int get_eval();
#endif
