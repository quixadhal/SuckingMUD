#ifndef PREPROCESS_H
#define PREPROCESS_H

defn_t *lookup_define (const char *);

#endif
