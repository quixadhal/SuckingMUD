#ifndef SOCKET_ERR_H
#define SOCKET_ERR_H
/*
 * socket_err.h
 */
extern char *error_strings[];

#endif
