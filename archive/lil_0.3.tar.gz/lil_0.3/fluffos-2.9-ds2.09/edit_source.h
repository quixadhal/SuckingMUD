#ifndef EDIT_SOURCE_H
#define EDIT_SOURCE_H

extern FILE *yyin;

#endif
