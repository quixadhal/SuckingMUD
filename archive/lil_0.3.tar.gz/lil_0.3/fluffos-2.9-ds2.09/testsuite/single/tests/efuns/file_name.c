void do_tests() {
    ASSERT(file_name() + ".c" == __FILE__);
}

