void foo() {
    switch ("hi") {
    case "foo".."bar":
    }
}
