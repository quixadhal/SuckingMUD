#include <globals.h>

inherit CLEAN_UP;
